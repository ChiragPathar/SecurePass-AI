

from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import mysql.connector
import hashlib
import datetime
import os
import json
import urllib.request
import urllib.error

# ─────────────────────────────────────────
# Load .env (no extra package needed)
# ─────────────────────────────────────────
_env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '.env')
if os.path.exists(_env_path):
    with open(_env_path) as _f:
        for _line in _f:
            _line = _line.strip()
            if _line and not _line.startswith('#') and '=' in _line:
                _k, _v = _line.split('=', 1)
                os.environ.setdefault(_k.strip(), _v.strip())

OPENAI_API_KEY = os.environ.get('OPENAI_API_KEY', '')

# ─────────────────────────────────────────
# Paths
# ─────────────────────────────────────────
BASE_DIR   = os.path.dirname(os.path.abspath(__file__))  # backend/
STATIC_DIR = os.path.dirname(BASE_DIR)                   # SecurePass AI/

app = Flask(__name__, static_folder=STATIC_DIR, static_url_path='')
app.secret_key = os.environ.get("SECRET_KEY")
CORS(app)

# ─────────────────────────────────────────
# Fixed admin credentials
# ─────────────────────────────────────────
ADMIN_EMAIL = os.environ.get("ADMIN_EMAIL")
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD")
ADMIN_SECRET_KEY = os.environ.get("ADMIN_SECRET_KEY")
MAX_SK_ATTEMPTS  = 3
LOCK_HOURS       = 24

# ─────────────────────────────────────────
# DB config
# ─────────────────────────────────────────
DB_CONFIG = dict(host='localhost', port=3306, user='root', password='')

# ─────────────────────────────────────────
# Auto-create database + table
# ─────────────────────────────────────────
def init_db():
    try:
        con = mysql.connector.connect(**DB_CONFIG)
        cur = con.cursor()
        cur.execute(
            "CREATE DATABASE IF NOT EXISTS SecurePassAI "
            "CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"
        )
        cur.execute("USE SecurePassAI")
        cur.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id               INT          AUTO_INCREMENT PRIMARY KEY,
                name             VARCHAR(100) NOT NULL,
                email            VARCHAR(150) NOT NULL UNIQUE,
                password_hash    VARCHAR(64)  NOT NULL,
                secret_key_hash  VARCHAR(64)  NOT NULL,
                hidden_word_hash VARCHAR(64)  NOT NULL,
                sk_fails         TINYINT      NOT NULL DEFAULT 0,
                locked_until     DATETIME     NULL,
                created_at       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB
        """)
        con.commit()
        cur.close(); con.close()
        print("[DB] ✅ SecurePassAI database and users table ready.")
    except mysql.connector.Error as e:
        print(f"[DB] ❌ {e}")
        print("[DB]    Make sure XAMPP MySQL is running on port 3306.")

def get_db():
    return mysql.connector.connect(**DB_CONFIG, database='SecurePassAI')

def sha(v): return hashlib.sha256(v.encode()).hexdigest()

def lock_msg(locked_until):
    d = locked_until - datetime.datetime.utcnow()
    return f'Account locked. Try again in {int(d.total_seconds()//3600)}h {int((d.total_seconds()%3600)//60)}m.'

def ok(msg, **kw):
    b = {'ok': True, 'msg': msg}; b.update(kw)
    return jsonify(b), 200

def err(msg, code=400):
    return jsonify({'ok': False, 'msg': msg}), code

# ─────────────────────────────────────────
# OpenAI helper
# ─────────────────────────────────────────
def call_openai(system_prompt: str, user_prompt: str) -> str:
    """Call OpenAI Chat Completions API using only stdlib (no openai package)."""
    if not OPENAI_API_KEY or OPENAI_API_KEY == 'paste_your_new_api_key_here':
        return None  # API key not configured

    payload = json.dumps({
        "model": "gpt-4o-mini",
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user",   "content": user_prompt}
        ],
        "max_tokens": 400,
        "temperature": 0.7
    }).encode('utf-8')

    req = urllib.request.Request(
        'https://api.openai.com/v1/chat/completions',
        data=payload,
        headers={
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {OPENAI_API_KEY}'
        },
        method='POST'
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read().decode())
            return data['choices'][0]['message']['content'].strip()
    except urllib.error.HTTPError as e:
        body = e.read().decode()
        print(f"[OpenAI] HTTP {e.code}: {body}")
        return None
    except Exception as e:
        print(f"[OpenAI] Error: {e}")
        return None

# ─────────────────────────────────────────
# Serve HTML pages
# ─────────────────────────────────────────
@app.route('/')
def home():
    return send_from_directory(STATIC_DIR, 'index.html')

@app.route('/login')
@app.route('/login.html')
def login_page():
    return send_from_directory(STATIC_DIR, 'login.html')

@app.route('/signup')
@app.route('/signup.html')
def signup_page():
    return send_from_directory(STATIC_DIR, 'signup.html')

@app.route('/admin-dashboard')
@app.route('/admin-dashboard.html')
def admin_page():
    f = os.path.join(STATIC_DIR, 'admin-dashboard.html')
    if os.path.exists(f): return send_from_directory(STATIC_DIR, 'admin-dashboard.html')
    return """<html><body style="background:#030712;color:#e5e7eb;font-family:sans-serif;
    display:flex;align-items:center;justify-content:center;height:100vh;margin:0;">
    <div style="text-align:center;"><h1 style="color:#00E5FF;">Welcome, Admin!</h1>
    <a href="/" style="color:#7C3AED;">Go to Home</a></div></body></html>"""

@app.route('/<path:filename>')
def static_files(filename): return send_from_directory(STATIC_DIR, filename)

# ─────────────────────────────────────────
# API: Ping
# ─────────────────────────────────────────
@app.route('/api/ping')
def ping():
    try:
        con = get_db(); con.close(); db_s = 'connected'
    except Exception as e:
        db_s = f'error: {e}'
    ai_s = 'configured' if (OPENAI_API_KEY and OPENAI_API_KEY != 'paste_your_new_api_key_here') else 'not configured'
    return jsonify({'status': 'ok', 'db': db_s, 'ai': ai_s})

# ─────────────────────────────────────────
# API: AI Password Analysis  ← NEW
# ─────────────────────────────────────────
@app.route('/api/ai-analyze', methods=['POST'])
def ai_analyze():
    data     = request.get_json(force=True) or {}
    password = (data.get('password') or '').strip()

    if not password:
        return err('Password is required.')
    if len(password) > 128:
        return err('Password too long.')

    # Build a safe prompt — we only send masked info, not the raw password
    length       = len(password)
    has_upper    = any(c.isupper() for c in password)
    has_lower    = any(c.islower() for c in password)
    has_digit    = any(c.isdigit() for c in password)
    has_symbol   = any(not c.isalnum() for c in password)
    is_common    = password.lower() in [
        'password','123456','qwerty','abc123','letmein','monkey',
        'master','dragon','111111','baseball','iloveyou','trustno1'
    ]

    char_info = []
    if has_upper:  char_info.append('uppercase letters')
    if has_lower:  char_info.append('lowercase letters')
    if has_digit:  char_info.append('numbers')
    if has_symbol: char_info.append('special symbols')

    sys_prompt = (
        "You are a cybersecurity expert specialising in password security. "
        "Give concise, practical, friendly advice. "
        "Respond in 3 clearly labeled sections using this exact format:\n\n"
        "**STRENGTH ANALYSIS**\n(2-3 sentences about strengths and weaknesses)\n\n"
        "**SECURITY TIPS**\n(3 bullet points with actionable tips)\n\n"
        "**IMPROVEMENT SUGGESTION**\n(1 specific improved version pattern, never show the actual password)"
    )

    user_prompt = (
        f"Analyse this password profile:\n"
        f"- Length: {length} characters\n"
        f"- Character types used: {', '.join(char_info) if char_info else 'only one type'}\n"
        f"- Is a known common password: {'YES — very risky!' if is_common else 'No'}\n\n"
        f"Provide strength analysis, security tips, and an improvement suggestion."
    )

    result = call_openai(sys_prompt, user_prompt)

    if result:
        return ok('Analysis complete.', analysis=result)
    else:
        # Fallback: rule-based analysis if OpenAI key not set or fails
        tips = []
        if length < 12:  tips.append('Use at least 12 characters for better security.')
        if not has_upper: tips.append('Add uppercase letters (A-Z).')
        if not has_lower: tips.append('Add lowercase letters (a-z).')
        if not has_digit: tips.append('Include numbers (0-9).')
        if not has_symbol: tips.append('Add special symbols (!@#$%^&*).')
        if is_common:    tips.append('This is a very common password — change it immediately.')

        if not tips:
            strength_text = 'Your password looks strong! Keep it safe and do not reuse it.'
        elif len(tips) <= 2:
            strength_text = 'Your password is decent but can be improved.'
        else:
            strength_text = 'Your password needs significant improvement.'

        fallback = (
            f"**STRENGTH ANALYSIS**\n{strength_text}\n\n"
            f"**SECURITY TIPS**\n" +
            '\n'.join(f'• {t}' for t in (tips[:3] if tips else ['Keep using unique passwords for every site.',
                                                                   'Enable two-factor authentication.',
                                                                   'Use a password manager.'])) +
            f"\n\n**IMPROVEMENT SUGGESTION**\nTry a passphrase pattern like: Word+Number+Symbol+Word "
            f"(e.g. Blue42!River) — easy to remember, hard to crack."
        )
        return ok('Analysis complete (local mode — AI key not configured).', analysis=fallback)

# ─────────────────────────────────────────
# API: AI Security Tips (general)  ← NEW
# ─────────────────────────────────────────
@app.route('/api/ai-tips', methods=['GET'])
def ai_tips():
    sys_prompt = (
        "You are a cybersecurity expert. Give exactly 5 practical, modern password security tips. "
        "Format as a numbered list. Each tip should be 1-2 sentences. Be concise and actionable."
    )
    user_prompt = "Give me 5 essential password security tips for everyday users in 2025."

    result = call_openai(sys_prompt, user_prompt)

    if result:
        return ok('Tips loaded.', tips=result)
    else:
        fallback = (
            "1. Use a unique password for every account — reusing passwords is the #1 security mistake.\n"
            "2. Make passwords at least 14 characters long with a mix of letters, numbers, and symbols.\n"
            "3. Enable two-factor authentication (2FA) on all important accounts.\n"
            "4. Use a password manager like Bitwarden or 1Password to store passwords securely.\n"
            "5. Never share passwords over email, SMS, or chat — no legitimate service will ask for them."
        )
        return ok('Tips loaded (local mode).', tips=fallback)

# ─────────────────────────────────────────
# API: SIGNUP
# ─────────────────────────────────────────
@app.route('/api/signup', methods=['POST'])
def signup():
    data        = request.get_json(force=True) or {}
    name        = (data.get('name')       or '').strip()
    email       = (data.get('email')      or '').strip().lower()
    password    = (data.get('password')   or '')
    secret_key  = (data.get('secretKey')  or '').strip()
    hidden_word = (data.get('hiddenWord') or '').strip().lower()

    if not all([name, email, password, secret_key, hidden_word]):
        return err('All fields are required.')
    if len(password) < 8:
        return err('Password must be at least 8 characters.')
    if len(secret_key) < 6:
        return err('Secret key must be at least 6 characters.')

    try:
        con = get_db(); cur = con.cursor(dictionary=True)
        cur.execute('SELECT id FROM users WHERE email=%s', (email,))
        if cur.fetchone():
            cur.close(); con.close()
            return err('An account with this email already exists.', 409)
        cur.execute(
            "INSERT INTO users (name,email,password_hash,secret_key_hash,hidden_word_hash,"
            "sk_fails,locked_until,created_at) VALUES (%s,%s,%s,%s,%s,0,NULL,%s)",
            (name, email, sha(password), sha(secret_key), sha(hidden_word),
             datetime.datetime.utcnow())
        )
        con.commit(); cur.close(); con.close()
        return ok(f'Account created for {name}! Please log in.')
    except mysql.connector.Error as e:
        return err(f'Database error: {e}', 500)

# ─────────────────────────────────────────
# API: LOGIN Step 1
# ─────────────────────────────────────────
@app.route('/api/login/step1', methods=['POST'])
def login_step1():
    data  = request.get_json(force=True) or {}
    email = (data.get('email')    or '').strip().lower()
    pw    = (data.get('password') or '')
    role  = (data.get('role')     or 'user')

    if not email or not pw: return err('Email and password are required.')

    if role == 'admin':
        if email != ADMIN_EMAIL or pw != ADMIN_PASSWORD:
            return err('Invalid admin email or password.', 401)
        return ok('Admin credentials verified.', role='admin', name='Chirag (Admin)')

    try:
        con = get_db(); cur = con.cursor(dictionary=True)
        cur.execute('SELECT * FROM users WHERE email=%s', (email,))
        user = cur.fetchone(); cur.close(); con.close()
        if not user:               return err('No account found. Please sign up first.', 404)
        if user['password_hash'] != sha(pw): return err('Wrong password.', 401)
        if user['locked_until'] and user['locked_until'] > datetime.datetime.utcnow():
            return err(lock_msg(user['locked_until']), 403)
        return ok('Credentials verified.', role='user', name=user['name'])
    except mysql.connector.Error as e:
        return err(f'Database error: {e}', 500)

# ─────────────────────────────────────────
# API: LOGIN Step 2
# ─────────────────────────────────────────
@app.route('/api/login/step2', methods=['POST'])
def login_step2():
    data  = request.get_json(force=True) or {}
    email = (data.get('email')     or '').strip().lower()
    sk    = (data.get('secretKey') or '').strip()
    role  = (data.get('role')      or 'user')

    if not email or not sk: return err('Email and secret key are required.')

    if role == 'admin':
        if email != ADMIN_EMAIL:   return err('Invalid admin email.', 401)
        if sk != ADMIN_SECRET_KEY: return err('Wrong admin secret key.', 401)
        return ok('Welcome, Chirag (Admin)!', role='admin', name='Chirag (Admin)', email=ADMIN_EMAIL)

    try:
        con = get_db(); cur = con.cursor(dictionary=True)
        cur.execute('SELECT * FROM users WHERE email=%s', (email,))
        user = cur.fetchone()
        if not user:
            cur.close(); con.close(); return err('User not found.', 404)
        if user['locked_until'] and user['locked_until'] > datetime.datetime.utcnow():
            cur.close(); con.close(); return err(lock_msg(user['locked_until']), 403)
        if user['secret_key_hash'] != sha(sk):
            fails = (user['sk_fails'] or 0) + 1
            if fails >= MAX_SK_ATTEMPTS:
                lt = datetime.datetime.utcnow() + datetime.timedelta(hours=LOCK_HOURS)
                cur.execute('UPDATE users SET sk_fails=%s,locked_until=%s WHERE email=%s', (fails,lt,email))
                con.commit(); cur.close(); con.close()
                return err('Too many wrong attempts! Account locked for 24 hours.', 403)
            else:
                cur.execute('UPDATE users SET sk_fails=%s WHERE email=%s', (fails,email))
                con.commit(); cur.close(); con.close()
                return err(f'Wrong secret key. {MAX_SK_ATTEMPTS-fails} attempt(s) remaining.', 401)
        cur.execute('UPDATE users SET sk_fails=0,locked_until=NULL WHERE email=%s', (email,))
        con.commit(); cur.close(); con.close()
        return ok(f'Welcome, {user["name"]}!', role='user', name=user['name'], email=email)
    except mysql.connector.Error as e:
        return err(f'Database error: {e}', 500)

# ─────────────────────────────────────────
# ─────────────────────────────────────────
# API: ADMIN — get all users (no sensitive fields)
# ─────────────────────────────────────────
ADMIN_TOKEN = '7f4a9c2b1e6d8f3a5c7b9e2d4f6a8c1b'   # simple static token

def check_admin_token():
    token = request.args.get('token', '') or (request.get_json(force=True) or {}).get('token', '')
    return token == ADMIN_TOKEN

@app.route('/api/admin/users', methods=['GET'])
def admin_get_users():
    if not check_admin_token():
        return jsonify({'ok': False, 'msg': 'Unauthorized'}), 401
    try:
        con = get_db(); cur = con.cursor(dictionary=True)
        cur.execute('''SELECT id, name, email, sk_fails, locked_until, created_at
                       FROM users ORDER BY id DESC''')
        users = cur.fetchall()
        cur.close(); con.close()
        for u in users:
            if u['locked_until']: u['locked_until'] = str(u['locked_until'])
            if u['created_at']:   u['created_at']   = str(u['created_at'])
        return jsonify({'ok': True, 'users': users, 'count': len(users)})
    except mysql.connector.Error as e:
        return jsonify({'ok': False, 'msg': f'DB error: {e}'}), 500

@app.route('/api/admin/users/<int:uid>', methods=['DELETE'])
def admin_delete_user(uid):
    if not check_admin_token(): return jsonify({'ok': False, 'msg': 'Unauthorized'}), 401
    try:
        con = get_db(); cur = con.cursor()
        cur.execute('DELETE FROM users WHERE id=%s', (uid,))
        con.commit(); cur.close(); con.close()
        return jsonify({'ok': True, 'msg': 'User deleted.'})
    except mysql.connector.Error as e:
        return jsonify({'ok': False, 'msg': f'DB error: {e}'}), 500

@app.route('/api/admin/users/<int:uid>/unlock', methods=['POST'])
def admin_unlock_user(uid):
    if not check_admin_token(): return jsonify({'ok': False, 'msg': 'Unauthorized'}), 401
    try:
        con = get_db(); cur = con.cursor()
        cur.execute('UPDATE users SET sk_fails=0, locked_until=NULL WHERE id=%s', (uid,))
        con.commit(); cur.close(); con.close()
        return jsonify({'ok': True, 'msg': 'User unlocked.'})
    except mysql.connector.Error as e:
        return jsonify({'ok': False, 'msg': f'DB error: {e}'}), 500

# API: RESET SECRET KEY
# ─────────────────────────────────────────
@app.route('/api/reset-secret-key', methods=['POST'])
def reset_secret_key():
    data        = request.get_json(force=True) or {}
    email       = (data.get('email')        or '').strip().lower()
    hidden_word = (data.get('hiddenWord')   or '').strip().lower()
    new_sk      = (data.get('newSecretKey') or '').strip()

    if not all([email, hidden_word, new_sk]): return err('All fields are required.')
    if len(new_sk) < 6: return err('New secret key must be at least 6 characters.')

    try:
        con = get_db(); cur = con.cursor(dictionary=True)
        cur.execute('SELECT * FROM users WHERE email=%s', (email,))
        user = cur.fetchone()
        if not user:
            cur.close(); con.close(); return err('User not found.', 404)
        if user['hidden_word_hash'] != sha(hidden_word):
            cur.close(); con.close(); return err('Hidden word does not match.', 401)
        cur.execute(
            'UPDATE users SET secret_key_hash=%s,sk_fails=0,locked_until=NULL WHERE email=%s',
            (sha(new_sk), email)
        )
        con.commit(); cur.close(); con.close()
        return ok('Secret key reset! You can now log in with your new key.')
    except mysql.connector.Error as e:
        return err(f'Database error: {e}', 500)

# ─────────────────────────────────────────
if __name__ == '__main__':
    ai_status = '✅ configured' if (OPENAI_API_KEY and OPENAI_API_KEY != 'paste_your_new_api_key_here') else '⚠️  NOT SET — edit backend/.env'
    print("\n" + "="*56)
    print("  SecurePass AI — Flask Backend v4")
    print(f"  OpenAI AI : {ai_status}")
    print("  ► http://localhost:5000")
    print("  ► http://localhost:5000/login")
    print("  ► http://localhost:5000/signup")
    print("  ► http://localhost:5000/api/ping")
    print("="*56 + "\n")
    init_db()
    app.run(debug=True, host='0.0.0.0', port=5000)

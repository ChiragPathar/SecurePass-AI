-- ════════════════════════════════════════
--  SecurePass AI — Database Setup
--  Run this in XAMPP phpMyAdmin or MySQL CLI
-- ════════════════════════════════════════

-- Create database
CREATE DATABASE IF NOT EXISTS SecurePassAI
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE SecurePassAI;

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id               INT          AUTO_INCREMENT PRIMARY KEY,
    name             VARCHAR(100) NOT NULL,
    email            VARCHAR(150) NOT NULL UNIQUE,
    password_hash    VARCHAR(64)  NOT NULL,   -- SHA-256 hex
    secret_key_hash  VARCHAR(64)  NOT NULL,   -- SHA-256 hex
    hidden_word_hash VARCHAR(64)  NOT NULL,   -- SHA-256 hex
    sk_fails         TINYINT      NOT NULL DEFAULT 0,
    locked_until     DATETIME     NULL,
    created_at       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- (Optional) Index for fast email lookup
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);

SELECT 'Database and table created successfully!' AS status;

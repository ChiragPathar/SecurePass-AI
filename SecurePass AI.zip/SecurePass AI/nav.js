/* ════════════════════════════════════════
   nav.js — shared navigation for all pages
   Include AFTER lucide script on every page
════════════════════════════════════════ */
(function() {
  var PAGES = [
    { label: 'Home',          href: 'index.html',          key: 'index'        },
    { label: 'PassChecker',   href: 'passchecker.html',    key: 'passchecker'  },
    { label: 'PassGenerator', href: 'passgenerator.html',  key: 'passgenerator'},
    { label: 'AI ✨',         href: 'ai.html',             key: 'ai', purple: true },
    { label: 'About',         href: 'about.html',          key: 'about'        }
  ];

  // Detect current page key from filename
  var path    = window.location.pathname;
  var file    = path.split('/').pop().replace('.html','') || 'index';
  var session = null;
  try { session = JSON.parse(sessionStorage.getItem('sp_session')); } catch(e) {}

  function buildNav() {
    var nav = document.getElementById('shared-nav');
    if (!nav) return;

    var linksAuth  = nav.querySelector('#nav-links-auth');
    var linksGuest = nav.querySelector('#nav-links-guest');
    var pill       = nav.querySelector('#user-profile-pill');

    if (!session) {
      if (linksAuth)  linksAuth.style.display  = 'none';
      if (linksGuest) linksGuest.style.display = 'flex';
      if (pill)       pill.style.display       = 'none';
      return;
    }

    /* Logged in */
    if (linksGuest) linksGuest.style.display = 'none';
    if (linksAuth)  linksAuth.style.display  = 'flex';
    if (pill)       pill.style.display       = 'flex';

    /* Build nav links */
    if (linksAuth) {
      linksAuth.innerHTML = '';
      PAGES.forEach(function(p) {
        if (p.key === 'about') {
          // About dropdown
          var wrapper = document.createElement('div');
          wrapper.style.cssText = 'position:relative;display:inline-block;';

          var btn = document.createElement('a');
          btn.href      = '#';
          btn.className = 'nav-link' + (file === 'about' || file === 'about-developer' ? ' active-nav' : '');
          btn.textContent = 'About';
          btn.style.cursor = 'pointer';
          btn.addEventListener('click', function(e) {
            e.preventDefault();
            var dd = document.getElementById('about-dropdown');
            if (dd) dd.style.display = dd.style.display === 'block' ? 'none' : 'block';
          });

          var dd = document.createElement('div');
          dd.id = 'about-dropdown';
          dd.style.cssText = 'display:none;position:absolute;top:2.2rem;right:0;min-width:11rem;' +
            'background:rgba(15,23,42,0.97);border:1px solid rgba(0,229,255,0.2);' +
            'border-radius:0.75rem;padding:0.4rem;box-shadow:0 12px 30px rgba(0,0,0,0.5);' +
            'backdrop-filter:blur(12px);z-index:100;';

          dd.innerHTML =
            '<a href="about.html" style="display:flex;align-items:center;gap:.5rem;' +
              'padding:.5rem .8rem;color:#e5e7eb;text-decoration:none;border-radius:.5rem;' +
              'font-size:.85rem;transition:background .15s;" ' +
              'onmouseover="this.style.background=\'rgba(0,229,255,0.08)\'" ' +
              'onmouseout="this.style.background=\'transparent\'">' +
              '<i data-lucide="shield-check" style="width:.9rem;height:.9rem;color:#00E5FF;"></i>' +
              'About SecurePass AI</a>' +
            '<a href="about-developer.html" style="display:flex;align-items:center;gap:.5rem;' +
              'padding:.5rem .8rem;color:#e5e7eb;text-decoration:none;border-radius:.5rem;' +
              'font-size:.85rem;transition:background .15s;" ' +
              'onmouseover="this.style.background=\'rgba(0,229,255,0.08)\'" ' +
              'onmouseout="this.style.background=\'transparent\'">' +
              '<i data-lucide="user" style="width:.9rem;height:.9rem;color:#a78bfa;"></i>' +
              'About Developer</a>';

          wrapper.appendChild(btn);
          wrapper.appendChild(dd);
          linksAuth.appendChild(wrapper);
        } else {
          var a = document.createElement('a');
          a.href      = p.href;
          a.className = 'nav-link' + (file === p.key ? ' active-nav' : '');
          a.textContent = p.label;
          if (p.purple) a.style.color = '#a78bfa';
          linksAuth.appendChild(a);
        }
      });

      // Close about dropdown on outside click
      document.addEventListener('click', function(e) {
        var dd = document.getElementById('about-dropdown');
        if (dd && dd.style.display === 'block') {
          var wrapper = dd.parentElement;
          if (wrapper && !wrapper.contains(e.target)) {
            dd.style.display = 'none';
          }
        }
      });
    }

    /* Profile icon + logout button (nav.js version for other pages) */
    if (pill) {
      var firstLetter = session.name.charAt(0).toUpperCase() || '?';
      pill.style.position = 'relative';
      pill.style.display  = 'flex';
      pill.style.alignItems = 'center';
      pill.style.gap = '0.5rem';

      pill.innerHTML =
        /* Avatar */
        '<div id="profile-avatar" onclick="toggleProfileDropdown()" ' +
             'style="width:2.2rem;height:2.2rem;border-radius:50%;' +
             'background:linear-gradient(135deg,#00E5FF,#7C3AED);' +
             'display:flex;align-items:center;justify-content:center;' +
             'font-size:1rem;font-weight:700;color:#030712;cursor:pointer;' +
             'border:2px solid rgba(0,229,255,0.35);user-select:none;">' +
             firstLetter +
        '</div>' +

        /* Logout button */
        '<button onclick="doLogout()" ' +
             'style="background:transparent;border:1px solid rgba(239,68,68,0.35);color:#f87171;' +
             'border-radius:0.5rem;padding:0.3rem 0.7rem;font-size:0.78rem;font-weight:600;' +
             'cursor:pointer;transition:background .2s;" ' +
             'onmouseover="this.style.background=\'rgba(239,68,68,0.12)\'" ' +
             'onmouseout="this.style.background=\'transparent\'">Logout</button>' +

        /* Dropdown */
        '<div id="profile-dropdown" ' +
             'style="display:none;position:absolute;top:2.8rem;right:0;min-width:13rem;' +
             'background:rgba(15,23,42,0.97);border:1px solid rgba(0,229,255,0.2);' +
             'border-radius:0.75rem;padding:0.5rem;' +
             'box-shadow:0 12px 30px rgba(0,0,0,0.5);backdrop-filter:blur(12px);z-index:100;">' +

          /* Name + email header */
          '<div style="padding:.6rem .75rem .5rem;border-bottom:1px solid rgba(0,229,255,0.12);margin-bottom:.4rem;">' +
            '<p style="font-size:.9rem;font-weight:700;color:#e5e7eb;margin-bottom:.1rem;">' + session.name + '</p>' +
            '<p style="font-size:.75rem;color:#6b7280;">' + (session.email||'') + '</p>' +
          '</div>' +

          '<a href="#" onclick="showProfile(event)" ' +
               'style="display:flex;align-items:center;gap:.5rem;padding:.45rem .75rem;' +
               'color:#e5e7eb;text-decoration:none;border-radius:.5rem;font-size:.85rem;" ' +
               'onmouseover="this.style.background=\'rgba(0,229,255,0.08)\'" ' +
               'onmouseout="this.style.background=\'transparent\'">' +
            '<i data-lucide="user" style="width:1rem;height:1rem;"></i>Profile</a>' +

          '<a href="#" onclick="showSavedPasswords(event)" ' +
               'style="display:flex;align-items:center;gap:.5rem;padding:.45rem .75rem;' +
               'color:#e5e7eb;text-decoration:none;border-radius:.5rem;font-size:.85rem;" ' +
               'onmouseover="this.style.background=\'rgba(0,229,255,0.08)\'" ' +
               'onmouseout="this.style.background=\'transparent\'">' +
            '<i data-lucide="key" style="width:1rem;height:1rem;"></i>Saved Passwords</a>' +

        '</div>';
    }
  }

  document.addEventListener('DOMContentLoaded', function() {
    buildNav();
    buildMobileNav();
    if (typeof lucide !== 'undefined') lucide.createIcons();
    
    // Close dropdowns when clicking outside
    document.addEventListener('click', function(e) {
      var dropdown = document.getElementById('profile-dropdown');
      var avatar   = document.getElementById('profile-avatar');
      if (dropdown && dropdown.style.display === 'block' && 
          !dropdown.contains(e.target) && avatar && !avatar.contains(e.target)) {
        dropdown.style.display = 'none';
      }
      var addrop = document.getElementById('about-dropdown');
      if (addrop && addrop.style.display === 'block') {
        var wrapper = addrop.parentElement;
        if (wrapper && !wrapper.contains(e.target)) addrop.style.display = 'none';
      }
    });
  });

  /* ── Mobile nav drawer ── */
  function buildMobileNav() {
    var nav = document.getElementById('shared-nav');
    if (!nav) return;
    var inner = nav.querySelector('.nav-inner');
    if (!inner) return;

    // Hamburger button
    var hamBtn = document.createElement('button');
    hamBtn.id = 'hamburger-btn';
    hamBtn.setAttribute('aria-label', 'Open menu');
    hamBtn.innerHTML =
      '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" ' +
      'stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
      '<line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/>' +
      '<line x1="3" y1="18" x2="21" y2="18"/></svg>';
    inner.appendChild(hamBtn);

    // Drawer
    var drawer  = document.createElement('div'); drawer.id  = 'mobile-nav-drawer';
    var overlay = document.createElement('div'); overlay.id = 'mobile-nav-overlay';
    var panel   = document.createElement('div'); panel.id   = 'mobile-nav-panel';
    overlay.addEventListener('click', function() { drawer.classList.remove('open'); });

    var curKey = window.location.pathname.split('/').pop().replace('.html','') || 'index';

    if (session) {
      var initials = session.name.charAt(0).toUpperCase();
      panel.innerHTML =
        '<div style="display:flex;align-items:center;gap:.75rem;padding:.5rem .85rem 1rem;' +
          'border-bottom:1px solid rgba(0,229,255,0.1);margin-bottom:.5rem;">' +
          '<div style="width:2.2rem;height:2.2rem;border-radius:50%;flex-shrink:0;' +
            'background:linear-gradient(135deg,#00E5FF,#7C3AED);' +
            'display:flex;align-items:center;justify-content:center;' +
            'font-size:1rem;font-weight:700;color:#030712;">' + initials + '</div>' +
          '<div><p style="font-size:.85rem;font-weight:600;color:#e5e7eb;">' + session.name + '</p>' +
            '<p style="font-size:.72rem;color:#6b7280;">' + (session.email||'') + '</p></div>' +
        '</div>';

      PAGES.forEach(function(p) {
        if (p.key === 'about') {
          panel.innerHTML += '<a class="mob-link mob-sub" href="about.html">🛡 About SecurePass AI</a>';
          panel.innerHTML += '<a class="mob-link mob-sub" href="about-developer.html">👤 About Developer</a>';
        } else {
          panel.innerHTML += '<a class="mob-link' + (curKey===p.key?' active':'') + '" href="' + p.href + '">' + p.label + '</a>';
        }
      });
      panel.innerHTML += '<div class="mob-divider"></div>';
      panel.innerHTML += '<a class="mob-link" href="profile.html">Profile</a>';
      panel.innerHTML += '<a class="mob-link" href="savedpasswords.html">Saved Passwords</a>';
      panel.innerHTML += '<div class="mob-divider"></div>';
      panel.innerHTML += '<button class="mob-link mob-logout" onclick="doLogout()">Logout</button>';
    } else {
      panel.innerHTML =
        '<a class="mob-link" href="login.html">Log In</a>' +
        '<a class="mob-link" href="signup.html">Sign Up</a>';
    }

    drawer.appendChild(overlay);
    drawer.appendChild(panel);
    document.body.appendChild(drawer);

    hamBtn.addEventListener('click', function() { drawer.classList.toggle('open'); });
  }

  // Profile dropdown functions
  window.toggleProfileDropdown = function() {
    var dropdown = document.getElementById('profile-dropdown');
    if (dropdown) {
      dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
    }
  };

  window.showProfile = function(e) {
    if (e) e.preventDefault();
    var dd = document.getElementById('profile-dropdown');
    if (dd) dd.style.display = 'none';
    window.location.href = 'profile.html';
  };

  window.showSavedPasswords = function(e) {
    if (e) e.preventDefault();
    var dd = document.getElementById('profile-dropdown');
    if (dd) dd.style.display = 'none';
    window.location.href = 'savedpasswords.html';
  };

  window.doLogout = function() {
    var dropdown = document.getElementById('profile-dropdown');
    if (dropdown) dropdown.style.display = 'none';
    sessionStorage.removeItem('sp_session');
    window.location.href = 'index.html';
  };

  /* Guard: redirect to login if not logged in (for protected pages) */
  window.requireLogin = function() {
    if (!session) window.location.href = 'login.html';
  };
})();

/* ════════════════════════════════════════
   SecurePass AI — main app logic
════════════════════════════════════════ */
'use strict';

// Global variables for better performance
let dropdownOpen = false;

document.addEventListener('DOMContentLoaded', () => {
  lucide.createIcons();

  // Close dropdown when clicking outside
  document.addEventListener('click', (e) => {
    const dropdown = document.getElementById('profile-dropdown');
    const avatar = document.getElementById('profile-avatar');
    if (dropdown && dropdownOpen && !dropdown.contains(e.target) && !avatar.contains(e.target)) {
      closeProfileDropdown();
    }
  });

  /* ── Password Checker ── */
  const checkInput    = document.getElementById('check-input');
  const results       = document.getElementById('checker-results');
  const scoreCircle   = document.getElementById('score-circle');
  const scoreText     = document.getElementById('score-text');
  const strengthLabel = document.getElementById('strength-label');
  const crackTime     = document.getElementById('crack-time');
  const criteriaList  = document.getElementById('criteria-list');
  const toggleVis     = document.getElementById('toggle-vis');

  if (checkInput) {
    const COMMON_PASSWORDS = [
      'password','123456','12345678','qwerty','abc123',
      'monkey','master','dragon','login','letmein'
    ];

    // Debounce for better performance
    let timeout;
    checkInput.addEventListener('input', () => {
      clearTimeout(timeout);
      timeout = setTimeout(() => {
        const pw = checkInput.value;
        if (!pw) { results.classList.remove('visible'); return; }
        results.classList.add('visible');

        const criteria = [
          { label: 'Min 8 characters',    pass: pw.length >= 8 },
          { label: 'Uppercase letter',    pass: /[A-Z]/.test(pw) },
          { label: 'Lowercase letter',    pass: /[a-z]/.test(pw) },
          { label: 'Number',              pass: /[0-9]/.test(pw) },
          { label: 'Symbol',              pass: /[^A-Za-z0-9]/.test(pw) },
          { label: 'Not common password', pass: !COMMON_PASSWORDS.includes(pw.toLowerCase()) },
        ];

        let score = Math.min(pw.length * 4, 30);
        criteria.forEach(c => { if (c.pass) score += 14; });
        score = Math.min(score, 100);

        const circumference = 213.6;
        scoreCircle.style.strokeDashoffset = circumference - (circumference * score / 100);
        scoreText.textContent = score;

        let color, label;
        if (score >= 75)      { color = '#22C55E'; label = 'Strong'; }
        else if (score >= 45) { color = '#EAB308'; label = 'Medium'; }
        else                  { color = '#EF4444'; label = 'Weak'; }

        scoreCircle.style.stroke  = color;
        strengthLabel.textContent = label;
        strengthLabel.style.color = color;

        /* Crack-time estimate */
        const entropy = pw.length * Math.log2(94);
        const secs    = Math.pow(2, entropy) / 1e10;
        let timeStr;
        if      (secs < 1)         timeStr = 'Instantly';
        else if (secs < 60)        timeStr = Math.round(secs) + ' seconds';
        else if (secs < 3600)      timeStr = Math.round(secs / 60) + ' minutes';
        else if (secs < 86400*365) timeStr = Math.round(secs / 3600) + ' hours';
        else {
          const y = secs / (86400 * 365);
          timeStr = y > 1e12 ? '∞ (centuries)' : Math.round(y).toLocaleString() + ' years';
        }
        crackTime.textContent = 'Estimated crack time: ' + timeStr;

        criteriaList.innerHTML = criteria.map(c =>
          `<div class="${c.pass ? 'crit-pass' : 'crit-fail'}">
            <i data-lucide="${c.pass ? 'check-circle' : 'x-circle'}" style="width:1rem;height:1rem;"></i>
            ${c.label}
          </div>`
        ).join('');
        lucide.createIcons();
      }, 150); // 150ms debounce for better performance
    });

    toggleVis.addEventListener('click', () => {
      checkInput.type = checkInput.type === 'password' ? 'text' : 'password';
    });
  }

  /* ── Password Generator ── */
  const genOutput = document.getElementById('gen-output');
  const genLength = document.getElementById('gen-length');
  const lenVal    = document.getElementById('len-val');
  const genBtn    = document.getElementById('gen-btn');
  const copyBtn   = document.getElementById('copy-btn');

  if (genOutput) {
    genLength.addEventListener('input', () => { lenVal.textContent = genLength.value; });

    genBtn.addEventListener('click', generatePassword);
    copyBtn.addEventListener('click', () => {
      if (genOutput.value) navigator.clipboard.writeText(genOutput.value);
    });

    generatePassword();
  }

  function generatePassword() {
    const len = parseInt(genLength.value, 10);
    let chars = '';
    if (document.getElementById('gen-upper').checked) chars += 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    if (document.getElementById('gen-lower').checked) chars += 'abcdefghijklmnopqrstuvwxyz';
    if (document.getElementById('gen-nums').checked)  chars += '0123456789';
    if (document.getElementById('gen-syms').checked)  chars += '!@#$%^&*()_+-=[]{}|;:,.<>?';
    if (!chars) chars = 'abcdefghijklmnopqrstuvwxyz';

    const arr = new Uint32Array(len);
    crypto.getRandomValues(arr);
    genOutput.value = Array.from(arr, v => chars[v % chars.length]).join('');
  }
});

// Profile dropdown functions
function showProfile(e) {
  if (e) e.preventDefault();
  var dropdown = document.getElementById('profile-dropdown');
  if (dropdown) dropdown.style.display = 'none';
  window.location.href = "profile.html";
}

function showSavedPasswords(e) {
  if (e) e.preventDefault();
  var dropdown = document.getElementById('profile-dropdown');
  if (dropdown) dropdown.style.display = 'none';
  window.location.href = "savedpasswords.html";
}
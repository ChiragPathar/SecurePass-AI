/* ════════════════════════════════════════
   SecurePass AI — auth logic (v5)
   Served by Flask → API base = /api
════════════════════════════════════════ */
'use strict';

var API = (window.location.protocol === 'file:')
  ? 'http://localhost:5000/api'
  : '/api';

/* ─── Helpers ─── */
function showMsg(id, text, type) {
  var el = document.getElementById(id);
  if (!el) return;
  el.textContent = text;
  el.className = 'msg ' + type + ' show';
}
function hideMsg(id) {
  var el = document.getElementById(id);
  if (el) el.className = 'msg';
}
function val(id) {
  var el = document.getElementById(id);
  return el ? el.value.trim() : '';
}

function apiPost(endpoint, body, onSuccess, onError) {
  fetch(API + endpoint, {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify(body)
  })
  .then(function(res) {
    return res.json().then(function(d) { return { ok: res.ok, data: d }; });
  })
  .then(function(res) {
    if (res.ok && res.data.ok) { onSuccess(res.data); }
    else { onError(res.data.msg || 'Something went wrong.'); }
  })
  .catch(function() {
    onError('Cannot reach server. Make sure Flask is running on port 5000.');
  });
}

/* ════════════════════════════
   LOGIN PAGE
════════════════════════════ */
function initLogin() {
  var form = document.getElementById('login-form');
  if (!form) return;

  var step         = 'credentials';
  var pendingEmail = '';
  var pendingRole  = 'user';

  /* ── Role tab switching ── */
  document.querySelectorAll('.role-tab').forEach(function(tab) {
    tab.addEventListener('click', function() {
      document.querySelectorAll('.role-tab').forEach(function(t) { t.classList.remove('active'); });
      tab.classList.add('active');

      var role = tab.getAttribute('data-role');
      document.getElementById('role-input').value = role;

      var badge      = document.getElementById('admin-badge');
      var forgotSec  = document.getElementById('forgot-sk-section');
      var signupLink = document.getElementById('signup-link');
      var title      = document.getElementById('login-title');
      var sub        = document.getElementById('login-sub');

      if (role === 'admin') {
        if (badge)      badge.style.display      = 'inline-flex';
        if (forgotSec)  forgotSec.style.display  = 'none';
        if (signupLink) signupLink.style.display  = 'none';
        if (title)      title.textContent         = 'Admin Login';
        if (sub)        sub.textContent           = 'Fixed credentials — authorised access only';
      } else {
        if (badge)      badge.style.display      = 'none';
        if (forgotSec)  forgotSec.style.display  = 'block';
        if (signupLink) signupLink.style.display  = 'block';
        if (title)      title.textContent         = 'Welcome back';
        if (sub)        sub.textContent           = 'Sign in to your account';
      }

      // Reset form back to step 1 if tab is switched
      step = 'credentials';
      var s1 = document.getElementById('step-credentials');
      var s2 = document.getElementById('step-secretkey');
      if (s1) s1.style.display = 'block';
      if (s2) s2.style.display = 'none';
      var btn = document.getElementById('submit-btn');
      if (btn) { btn.textContent = 'Continue'; btn.style.display = 'block'; }
      // Also reset forgot-sk state
      var box    = document.getElementById('forgot-sk-box');
      var skWrap = document.getElementById('sk-input-wrap');
      var fLink  = document.getElementById('forgot-sk-link');
      if (box)    box.style.display    = 'none';
      if (skWrap) skWrap.style.display = 'block';
      if (fLink)  fLink.style.display  = 'inline-block';
      hideMsg('form-msg');
    });
  });

  /* ── Eye buttons ── */
  document.querySelectorAll('.eye-btn').forEach(function(btn) {
    btn.addEventListener('click', function() {
      var inp = btn.parentElement.querySelector('input');
      if (inp) inp.type = inp.type === 'password' ? 'text' : 'password';
    });
  });

  /* ── Form submit ── */
  form.addEventListener('submit', function(e) {
    e.preventDefault();
    if (step === 'credentials') doStep1();
    else doStep2();
  });

  function doStep1() {
    hideMsg('form-msg');
    var email = val('email');
    var pw    = document.getElementById('password').value;
    var role  = document.getElementById('role-input').value;

    if (!email || !pw) {
      showMsg('form-msg', 'Please enter your email and password.', 'error'); return;
    }

    var btn = document.getElementById('submit-btn');
    if (btn) { btn.disabled = true; btn.textContent = 'Checking…'; }

    apiPost('/login/step1', { email: email, password: pw, role: role },
      function(data) {
        pendingEmail = email;
        pendingRole  = role;
        step = 'secretkey';
        var s1 = document.getElementById('step-credentials');
        var s2 = document.getElementById('step-secretkey');
        if (s1) s1.style.display = 'none';
        if (s2) s2.style.display = 'block';
        // Make sure secret key field and submit btn are visible (not in forgot state)
        var skWrap = document.getElementById('sk-input-wrap');
        var fLink  = document.getElementById('forgot-sk-link');
        var fBox   = document.getElementById('forgot-sk-box');
        if (skWrap) skWrap.style.display = 'block';
        if (fLink)  fLink.style.display  = 'inline-block';
        if (fBox)   fBox.style.display   = 'none';
        if (btn) { btn.disabled = false; btn.textContent = 'Verify & Sign In'; btn.style.display = 'block'; }
        hideMsg('form-msg');
      },
      function(errMsg) {
        showMsg('form-msg', errMsg, 'error');
        if (btn) { btn.disabled = false; btn.textContent = 'Continue'; }
      }
    );
  }

  function doStep2() {
    hideMsg('form-msg');
    var sk = document.getElementById('secret-key').value.trim();
    if (!sk) { showMsg('form-msg', 'Please enter your secret key.', 'error'); return; }

    var btn = document.getElementById('submit-btn');
    if (btn) { btn.disabled = true; btn.textContent = 'Verifying…'; }

    apiPost('/login/step2', { email: pendingEmail, secretKey: sk, role: pendingRole },
      function(data) {
        sessionStorage.setItem('sp_session', JSON.stringify({
          name: data.name, role: data.role, email: data.email
        }));
        showMsg('form-msg', 'Welcome, ' + data.name + '! Redirecting…', 'success');
        setTimeout(function() {
          window.location.href = data.role === 'admin' ? 'admin-dashboard.html' : 'index.html';
        }, 1000);
      },
      function(errMsg) {
        showMsg('form-msg', errMsg, 'error');
        if (btn) { btn.disabled = false; btn.textContent = 'Verify & Sign In'; }
      }
    );
  }

  /* ── Forgot secret key ── */
  var forgotLink = document.getElementById('forgot-sk-link');
  if (forgotLink) {
    forgotLink.addEventListener('click', function(e) {
      e.preventDefault();
      var box    = document.getElementById('forgot-sk-box');
      var skWrap = document.getElementById('sk-input-wrap');
      var subBtn = document.getElementById('submit-btn');
      var fLink  = document.getElementById('forgot-sk-link');

      // Hide role tabs + title + subtitle
      var roleTabs = document.querySelector('.role-tabs');
      var adminBadge = document.getElementById('admin-badge');
      var loginTitle = document.getElementById('login-title');
      var loginSub   = document.getElementById('login-sub');
      if (roleTabs)   roleTabs.style.display   = 'none';
      if (adminBadge) adminBadge.style.display  = 'none';
      if (loginTitle) loginTitle.style.display  = 'none';
      if (loginSub)   loginSub.style.display    = 'none';

      // Show recovery box, hide secret key field + submit btn + forgot link
      if (box)    box.style.display    = 'block';
      if (skWrap) skWrap.style.display = 'none';
      if (subBtn) subBtn.style.display = 'none';
      if (fLink)  fLink.style.display  = 'none';
    });
  }

  // "Back to Secret Key" button inside recovery box
  var cancelRecoverBtn = document.getElementById('cancel-recover-btn');
  if (cancelRecoverBtn) {
    cancelRecoverBtn.addEventListener('click', function() {
      var box    = document.getElementById('forgot-sk-box');
      var skWrap = document.getElementById('sk-input-wrap');
      var subBtn = document.getElementById('submit-btn');
      var fLink  = document.getElementById('forgot-sk-link');

      // Restore role tabs + title + subtitle
      var roleTabs = document.querySelector('.role-tabs');
      var loginTitle = document.getElementById('login-title');
      var loginSub   = document.getElementById('login-sub');
      if (roleTabs)   roleTabs.style.display   = '';
      if (loginTitle) loginTitle.style.display  = '';
      if (loginSub)   loginSub.style.display    = '';

      if (box)    box.style.display    = 'none';
      if (skWrap) skWrap.style.display = 'block';
      if (subBtn) subBtn.style.display = 'block';
      if (fLink)  fLink.style.display  = 'inline-block';
      hideMsg('recover-msg');
    });
  }

  var recoverBtn = document.getElementById('recover-btn');
  if (recoverBtn) {
    recoverBtn.addEventListener('click', function() {
      var hw    = val('recover-word').toLowerCase();
      var newsk = document.getElementById('new-secret-key').value.trim();

      if (!hw || !newsk) { showMsg('recover-msg', 'Fill in both fields.', 'error'); return; }
      if (newsk.length < 6) { showMsg('recover-msg', 'New key must be at least 6 characters.', 'error'); return; }
      if (!pendingEmail)  { showMsg('recover-msg', 'Complete Step 1 first.', 'error'); return; }

      recoverBtn.disabled    = true;
      recoverBtn.textContent = 'Resetting…';

      apiPost('/reset-secret-key',
        { email: pendingEmail, hiddenWord: hw, newSecretKey: newsk },
        function(data) {
          showMsg('recover-msg', data.msg, 'success');
          document.getElementById('forgot-sk-box').style.display  = 'none';
          document.getElementById('secret-key').value             = '';
          recoverBtn.disabled    = false;
          recoverBtn.textContent = 'Reset Secret Key';
        },
        function(errMsg) {
          showMsg('recover-msg', errMsg, 'error');
          recoverBtn.disabled    = false;
          recoverBtn.textContent = 'Reset Secret Key';
        }
      );
    });
  }
}

/* ════════════════════════════
   SIGNUP PAGE
════════════════════════════ */
function initSignup() {
  var form = document.getElementById('signup-form');
  if (!form) return;

  /* Eye buttons */
  document.querySelectorAll('.eye-btn').forEach(function(btn) {
    btn.addEventListener('click', function() {
      var inp = btn.parentElement.querySelector('input');
      if (inp) inp.type = inp.type === 'password' ? 'text' : 'password';
    });
  });

  form.addEventListener('submit', function(e) {
    e.preventDefault();
    hideMsg('form-msg');

    var name  = val('name');
    var email = val('email');
    var pw    = document.getElementById('password').value;
    var pw2   = document.getElementById('confirm-password').value;
    var sk    = document.getElementById('user-secret-key').value.trim();
    var hw    = val('hidden-word').toLowerCase();
    var terms = document.getElementById('terms-check');

    if (!name)         { showMsg('form-msg', 'Please enter your full name.', 'error');            return; }
    if (!email)        { showMsg('form-msg', 'Please enter your email address.', 'error');        return; }
    if (!pw)           { showMsg('form-msg', 'Please enter a password.', 'error');                return; }
    if (pw.length < 8) { showMsg('form-msg', 'Password must be at least 8 characters.', 'error'); return; }
    if (pw !== pw2)    { showMsg('form-msg', 'Passwords do not match.', 'error');                 return; }
    if (!sk)           { showMsg('form-msg', 'Please set a Secret Key.', 'error');                return; }
    if (sk.length < 6) { showMsg('form-msg', 'Secret Key must be at least 6 characters.', 'error'); return; }
    if (!hw)           { showMsg('form-msg', 'Please set a Hidden Recovery Word.', 'error');      return; }

    var btn = form.querySelector('.auth-submit');
    if (btn) { btn.disabled = true; btn.textContent = 'Creating…'; }

    apiPost('/signup',
      { name: name, email: email, password: pw, secretKey: sk, hiddenWord: hw },
      function(data) {
        showMsg('form-msg', data.msg, 'success');
        setTimeout(function() { window.location.href = 'login.html'; }, 1500);
      },
      function(errMsg) {
        showMsg('form-msg', errMsg, 'error');
        if (btn) { btn.disabled = false; btn.textContent = 'Create Account'; }
      }
    );
  });
}

/* ─── Boot ─── */
document.addEventListener('DOMContentLoaded', function() {
  if (typeof lucide !== 'undefined') lucide.createIcons();
  initLogin();
  initSignup();
});
